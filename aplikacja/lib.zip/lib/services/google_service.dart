import 'package:Hive/database/database_helper.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

class GoogleService {
  static Future<GoogleSignInAccount?> googleSignIn() async {
    final GoogleSignIn googleSignIn = GoogleSignIn(
      scopes: <String>[
        'email',
      ],
    );

    await googleSignIn.signOut();

    var googleUser = await googleSignIn.signIn();

    print(googleUser.toString());

    return googleUser;
  }

  static Future<void> _registerGoogleUser(GoogleSignInAccount googleUser, BuildContext context) async {
      final name = googleUser.displayName!.contains(" ") ? googleUser.displayName?.split(" ")[0] : googleUser.displayName;
      final surname = googleUser.displayName!.contains(" ") ? googleUser.displayName?.split(" ")[1] : "";
      final age = 0;
      final userNickname = googleUser.displayName;
      final email = googleUser.email;
      final password = googleUser.id;

      try {
        await DatabaseHelper.addUser(name!, surname!, age, userNickname!, email, password);

        // Wyświetl komunikat o powodzeniu i przejdź do ekranu logowania
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Rejestracja pomyślna!')),
        );
      } catch (e) {
        // Wyświetl komunikat o błędzie
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Błąd rejestracji przez Google: $e')),
        );
      }
  }
}