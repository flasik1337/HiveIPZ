import 'package:flutter/material.dart';

class HiveColors {
  static const Color main = Color(0xFFFFC800);
  static const Color weakAccent = Color(0xFFFFCF80);
  static const Color free = Color(0xFF388E3C);
  static const Color strongAccent = Color(0xFFFFC107);
}