import '../models/event.dart';

class RecommendationService {
  static double calculateScore(
      Event event, List<String> preferredTypes, List<String> recentSearches) {
    double score = 0.0;

    // +1 jeżeli wydarzenie jest w preferowanym typie
    if (preferredTypes.contains(event.type)) {
      score += 1.0;
    }

    // +0.5, jeżeli użytkownk wyszukiwał podobne
    for (final keyword in recentSearches) {
      final lowerKeyword = keyword.toLowerCase();
      if (event.name.toLowerCase().contains(lowerKeyword) ||
          event.description.toLowerCase().contains(lowerKeyword)) {
        score += 0.5;
      }
    }

    // +1 jeżeli promowane
    if (event.isPromoted) {
      score += 1.0;
    }

    // +stosunek zapisanych do maksymalnych, jeżeli popularne (do przemyślenia)
    if (event.maxParticipants > 0) {
      score += (event.registeredParticipants / event.maxParticipants) * 2;
    }



    return score;
  }

  static List<Event> attachScores(
      List<Event> events, List<String> preferredTypes, List<String> recentSearches) {
    return events.map((e) {
      return e.copyWith(
        recommendationScore: calculateScore(e, preferredTypes, recentSearches),
      );
    }).toList();
  }
}
